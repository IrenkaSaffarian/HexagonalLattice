import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
 
import java.util.*;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.lang.Math;

/**
 * Lattice Turtles! They draw a hexagonal lattice!
 *
 * @Irenka
 * @Oct. 7, 2020
 */
public class LatticeTurtle 
{
    private int hexSides;
    private int numVertical;
    private int numHorizontal;
    protected double[] rows = null;
    protected double[] columns = null;
    
    //will make a new hexagonal lattice on the world
    public LatticeTurtle(int numV, int numH, int x)
    {
        hexSides= x;
        numVertical = numV;
        numHorizontal = numH;
        
        rows = new double[2*(numV+1)];
        columns = new double[2*numH+1];
        
            for (int i=0; i< rows.length; i++)
        {
            if (i==0)
            {rows[i] = 0;}
            else if (i%2 ==1)
            {rows[i] = rows[i-1] + (double) x/2;}
            else if (i%2==0)
            {rows[i] = rows[i-1] + x;}
        }
        
            for (int i=0; i<columns.length; i++)
        {
            
             columns[i] = i* (x*Math.sqrt(3)/2);
        }
        
        /*for (double c : columns)      
        { System.out.println(c);}
        
        for (double r : rows)      
        { System.out.println(r);}
        */
        
    }
    
    public double[] getRows()
    {
        return rows;
    }
    
    public double[] getColumns()
    {
        return columns;
    }
    
    public int getNumV()
    {
        return numVertical;
    }
    
    public int getNumH()
    {
        return numHorizontal;
    }
    
    public static void main (String[] args)
    {
           
    }
}
