import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
 
import java.util.*;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.lang.Math;

    public class Grid extends JPanel
    {  
        private double[] rows;
        private double[] columns;
        private int numVertical;
        private int numHorizontal;
       
        public void meet(double[] a, double[] b, int V, int H)
        {
            rows = a;
            columns = b;
            numVertical = V;
            numHorizontal = H;
            
        }
        
        @Override
        public void paint(Graphics g)
        {
            Graphics2D g2d = (Graphics2D) g;
            
            for ( int i=0; i<columns.length; i++)
            {     
                if (i%2==0)
            {
                for (int n=0; n<=numVertical; n++)
                {
                    if (n%2==1)
                    {
                      g2d.draw(new Line2D.Double(columns[i], 
                      rows[n*2], columns[i], rows[n*2-1]));  
                    }
                    
                }
            }
                else if (i%2==1)
            {
                for (int n=1; n<=numVertical; n++)
                {
                    if (n%2==0)
                    {
                      g2d.draw(new Line2D.Double(columns[i], 
                      rows[n*2], columns[i], rows[n*2-1]));  
                    }
                    
                }
            }
            }
            /* Add for optical illusion!
                for ( int i=0; i<rows.length; i++)
            {                
             g2d.draw(new Line2D.Double( 0., rows[i], 600., rows[i]));
            }*/
           
            
            
                for ( int i=0; i<numVertical; i++)
            {   
                for (int c=0; c<numHorizontal; c++)
            {
                if (i%2==1)
                {
                    g2d.draw(new Line2D.Double(columns[c*2], rows[i*2], 
                    columns[c*2+1], rows[i*2+1]));
                    g2d.draw(new Line2D.Double(columns[c*2], rows[(i*2)-1], 
                    columns[c*2+1], rows[(i*2)-2]));
                    
                  if (c!=0)//delete for optical illusion!
                  {
                    g2d.draw(new Line2D.Double(columns[c*2], rows[i*2-1], 
                    columns[c*2-1], rows[i*2-2]));
                    g2d.draw(new Line2D.Double(columns[c*2], rows[i*2], 
                    columns[c*2-1], rows[i*2+1]));
                  }
                  
                }
            }
            }
        }
        
    
    
        public static void main (String[] args)
       {
           LatticeTurtle oogway = new LatticeTurtle(13, 13, 40);
           JFrame world = new JFrame("Some frame");
           world.setSize(600, 600);
           Grid uuguei = new Grid();
           uuguei.meet(oogway.getRows(), oogway.getColumns(), 
           oogway.getNumV(), oogway.getNumH());
           world.setContentPane(uuguei);
           world.setVisible(true);
           world.setDefaultCloseOperation(world.EXIT_ON_CLOSE);
       }
    }   